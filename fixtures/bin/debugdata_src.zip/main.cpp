// arm-none-eabi-g++.exe .\main.cpp .\start.s
//   -mcpu=cortex-m7 
//   -mthumb
//   -specs=nano.specs -specs=nosys.specs 
//   -mfloat-abi=hard
//   -nostdlib
//   -o out.elf

#include "main.hpp"

extern void func1(void);
extern void func2(void);
extern void func3(void);
extern void func4(void);
extern void func5(void);

static someclass class1;
static N::derived<int, long> class2;

int main(void)
{
    func1();
    func2();
    func3();
    func4();
    func5();

    class1.do_something();
    class2.do_something(42);

    return 0;
}
