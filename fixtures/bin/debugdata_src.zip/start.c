extern int main(void);

typedef void (*function_t)();
extern function_t __init_array_start;
extern function_t __init_array_end;

void _start(void)
{
    function_t* pfn;
    for (pfn = &__init_array_start; pfn < &__init_array_end; pfn++) {
        (*pfn)();
    };

    main();
}

void SystemInit(void)
{

}