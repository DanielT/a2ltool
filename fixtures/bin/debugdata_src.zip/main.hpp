
class base1 {
    public:
        int base1_var;
};

class base2 {
    protected:
        long base2var;
};

class someclass : public base1, public base2 {
    public:
        using foo = const long*;

        someclass() : ss(0) {
        }
        void do_something() {
            this->base1_var = this->base1_var + 1;
            this->base2var = this->base2var + 3;
        }
        
        void do_something(foo x) {
            this->base2var = *x;
        }

        static unsigned long class_static;

    private:
        signed short ss;
};

namespace N {
    template<class T> class template_base {
        private:
            T basevar;
    };

    template<class U, class V> class derived : template_base<U> {
        public:
            void do_something(V x) {
                this->some_var = x;
            }
            V some_var;
    };
};
