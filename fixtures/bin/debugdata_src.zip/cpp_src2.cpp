#include "main.hpp"

signed char var_sint8;
unsigned char var_uint8;
signed short var_sint16;
unsigned short var_uint16;
signed long var_sint32;
unsigned long var_uint32;
signed long long var_sint64;
unsigned long long var_uint64;
float var_fl32;
double var_fl64;

unsigned long* var_p_uint32;

unsigned char var_array[33];
float var_multidim[10][3][7];

void func2(void)
{
    static long staticvar = 0l;
}