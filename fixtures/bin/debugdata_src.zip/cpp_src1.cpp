#include "main.hpp"

struct s_bitfield;
extern s_bitfield bitfield;

static someclass class3;
static N::derived<int, long> class4;

static struct s_bitfield* ptr_s_bitfield;

void func1(void)
{
    class3.do_something();
    class4.do_something(666);
    ptr_s_bitfield = &bitfield;
}