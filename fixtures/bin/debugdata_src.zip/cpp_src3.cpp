#include "main.hpp"

typedef struct {
    char x;
    long y;
} t_struct;

typedef struct {
    int val1;
    union
    {
        int val2;
        int val3;
    };
    t_struct it;
    struct {
        int foo;
    };
    t_struct arr[1];
} somestruct;

void func3(void)
{
    static somestruct structvar;
    static long staticvar[42];
}