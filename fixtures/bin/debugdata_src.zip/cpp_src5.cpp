#include "main.hpp"

enum en_tag {
    E1_VALUE
};

enum en_tag enum_var1;

typedef enum {
    E2_VALUE,
    INVALID = -99
} en2_t;

en2_t enum_var2;

enum {
    E3_VALUE
} enum_var3;

void func5(void)
{
    enum_var3 = E3_VALUE;
}

namespace ns1 {
    namespace ns2 {
        int var;

        void func(void)
        {
            static int staticvar = 0;
            var++;
            staticvar++;
        }
    }
}
