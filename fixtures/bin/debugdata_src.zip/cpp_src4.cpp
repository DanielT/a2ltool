#include "main.hpp"

struct s_bitfield {
    signed int var  : 5;
    unsigned int var2 : 5;
    int var3 : 23;
    int var4 : 1;
    char other;
};

s_bitfield bitfield;

void func4(void)
{
    bitfield.var4 = 0;
}